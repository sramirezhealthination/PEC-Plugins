var currentV = jwplayer().getPlaylistItem();
jwplayer().on('adError', function(e) {
ga("send", "event", "JW Player Video", "Ad Error", pageTitle, {nonInteraction: true});
console.log('adError');
});
jwplayer().on('adBlock', function(e) {
ga("send", "event", "JW Player Video", "Ad Block", pageTitle, {nonInteraction: true});
gtag('event', 'HN Page Ad Blocks', 'Ad Block', pageTitle, {nonInteraction: true});
console.log('adBlock');
});
jwplayer().on('autostartNotAllowed', function(e) {
ga("send", "event", "JW Player Video", "Auto Start Not Allowed", pageTitle, {nonInteraction: true});
console.log('autostartNotAllowed');
});

jwplayer().on('adStarted', function(e) {
ga("send", "event", "JW Player Video", "Ad Started", pageTitle, {nonInteraction: true});
gtag('event', 'HN Video Ad Starts', 'Ad Started', pageTitle, {nonInteraction: true});
console.log('adStarted');
});
jwplayer().on('adComplete', function(e) {
ga("send", "event", "JW Player Video", "Ad Complete", pageTitle, {nonInteraction: true});
gtag('event', 'HN Video Ad Completions (100%)', 'Ad Complete', pageTitle, {nonInteraction: true});
console.log('adComplete');
console.log(e);
});
jwplayer().on('adViewableImpression', function(e) {
ga("send", "event", "JW Player Video", "Ad Viewable Impression", pageTitle, {nonInteraction: true});
console.log('adViewableImpression');
});
